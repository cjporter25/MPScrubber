# mpscrubber.ps1

# Activate the virtual environment
. "$PSScriptRoot\..\ .venv\Scripts\Activate.ps1"

# Run the application using pythonw.exe, i.e., W/O TERMINAL
# Start-Process "$PSScriptRoot\..\ .venv\Scripts\pythonw.exe" -ArgumentList "$PSScriptRoot\..\main.py"
# Run the application using pythonw.exe, i.e., W/ TERMINAL
Start-Process "$PSScriptRoot\..\ .venv\Scripts\python.exe" -ArgumentList "$PSScriptRoot\..\main.py"